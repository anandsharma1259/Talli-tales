import fs from 'fs';
import path from 'path';
import { Express } from 'express';
import archiver from 'archiver';

export function setupDownload(app: Express) {
  // Route to download the entire app as a zip file
  app.get('/api/download', (req, res) => {
    try {
      // Create a file to stream archive data to
      const downloadsDir = path.join(process.cwd(), 'downloads');
      const zipPath = path.join(downloadsDir, 'talli_tales_app.zip');
      
      // Ensure downloads directory exists
      if (!fs.existsSync(downloadsDir)) {
        fs.mkdirSync(downloadsDir, { recursive: true });
      }
      
      const output = fs.createWriteStream(zipPath);
      const archive = archiver('zip', {
        zlib: { level: 9 } // Sets the compression level
      });

      output.on('close', function() {
        console.log(archive.pointer() + ' total bytes');
        console.log('Archive has been finalized and the output file descriptor has been closed.');
        
        // Send the file to the client
        res.download(zipPath, 'talli_tales_app.zip', (err) => {
          if (err) {
            console.error('Error sending zip file:', err);
          }
          // Clean up: delete the zip file after sending it (with a delay to ensure download completes)
          setTimeout(() => {
            try {
              if (fs.existsSync(zipPath)) {
                fs.unlinkSync(zipPath);
              }
            } catch (e) {
              console.error('Error cleaning up zip file:', e);
            }
          }, 10000);
        });
      });

      archive.on('error', function(err) {
        console.error('Archive error:', err);
        res.status(500).json({ message: 'Error creating archive' });
      });

      // Pipe archive data to the file
      archive.pipe(output);

      // Add files and directories to include in the zip
      const rootDir = process.cwd();
      
      // Add client files
      archive.directory(path.join(rootDir, 'client'), 'client');
      
      // Add server files
      archive.directory(path.join(rootDir, 'server'), 'server');
      
      // Add shared files
      archive.directory(path.join(rootDir, 'shared'), 'shared');
      
      // Add configuration files
      ['package.json', 'tsconfig.json', 'tailwind.config.ts', 'theme.json', 'vite.config.ts'].forEach(file => {
        const filePath = path.join(rootDir, file);
        if (fs.existsSync(filePath)) {
          archive.file(filePath, { name: file });
        }
      });

      // Finalize the archive
      archive.finalize();
    } catch (error) {
      console.error('Error creating zip file:', error);
      res.status(500).json({ message: 'Error creating downloadable archive' });
    }
  });
}