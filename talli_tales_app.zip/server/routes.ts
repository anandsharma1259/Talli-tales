import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupDownload } from "./download";
import { insertTaskSchema, insertTimesheetSchema, insertServiceRequestSchema, insertClaimSchema, insertFeedbackSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  
  // Get current user profile
  app.get("/api/user/profile", async (req, res) => {
    try {
      // In a real app, this would come from a session
      const userId = 1;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't return the password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Admin access toggle endpoint
  app.post("/api/admin/toggle", async (req, res) => {
    try {
      // In a real app, this would come from a session
      const userId = 1;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Toggle admin status
      const updated = await storage.updateUser(userId, { 
        isAdmin: user.isAdmin ? false : true 
      });
      
      // Don't return the password
      const { password, ...userWithoutPassword } = updated!;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error toggling admin status:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Tasks API
  
  // Get tasks for current user
  app.get("/api/tasks", async (req, res) => {
    try {
      // In a real app, this would come from a session
      const userId = 1;
      const tasks = await storage.getTasksByUser(userId);
      res.json(tasks);
    } catch (error) {
      console.error("Error fetching tasks:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create new task
  app.post("/api/tasks", async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const newTask = await storage.createTask(taskData);
      res.status(201).json(newTask);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: fromZodError(error).message });
      }
      console.error("Error creating task:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Timesheet API
  
  // Get timesheets for current user
  app.get("/api/timesheets", async (req, res) => {
    try {
      // In a real app, this would come from a session
      const userId = 1;
      const timesheets = await storage.getTimesheetsByUser(userId);
      res.json(timesheets);
    } catch (error) {
      console.error("Error fetching timesheets:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create new timesheet entry
  app.post("/api/timesheets", async (req, res) => {
    try {
      const timesheetData = insertTimesheetSchema.parse(req.body);
      const newTimesheet = await storage.createTimesheet(timesheetData);
      res.status(201).json(newTimesheet);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid timesheet data", errors: fromZodError(error).message });
      }
      console.error("Error creating timesheet:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Service Requests API
  
  // Get service requests for current user
  app.get("/api/service-requests", async (req, res) => {
    try {
      // In a real app, this would come from a session
      const userId = 1;
      const serviceRequests = await storage.getServiceRequestsByUser(userId);
      res.json(serviceRequests);
    } catch (error) {
      console.error("Error fetching service requests:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create new service request
  app.post("/api/service-requests", async (req, res) => {
    try {
      const serviceRequestData = insertServiceRequestSchema.parse(req.body);
      const newServiceRequest = await storage.createServiceRequest(serviceRequestData);
      res.status(201).json(newServiceRequest);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid service request data", errors: fromZodError(error).message });
      }
      console.error("Error creating service request:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Claims API
  
  // Get claims for current user
  app.get("/api/claims", async (req, res) => {
    try {
      // In a real app, this would come from a session
      const userId = 1;
      const claims = await storage.getClaimsByUser(userId);
      res.json(claims);
    } catch (error) {
      console.error("Error fetching claims:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create new claim
  app.post("/api/claims", async (req, res) => {
    try {
      const claimData = insertClaimSchema.parse(req.body);
      const newClaim = await storage.createClaim(claimData);
      res.status(201).json(newClaim);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid claim data", errors: fromZodError(error).message });
      }
      console.error("Error creating claim:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Feedback API
  
  // Submit feedback
  app.post("/api/feedback", async (req, res) => {
    try {
      const feedbackData = insertFeedbackSchema.parse(req.body);
      const newFeedback = await storage.createFeedback(feedbackData);
      res.status(201).json(newFeedback);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid feedback data", errors: fromZodError(error).message });
      }
      console.error("Error submitting feedback:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Setup download route
  setupDownload(app);

  const httpServer = createServer(app);
  return httpServer;
}
