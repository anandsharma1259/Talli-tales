import { 
  users, type User, type InsertUser,
  tasks, type Task, type InsertTask,
  timesheets, type Timesheet, type InsertTimesheet,
  serviceRequests, type ServiceRequest, type InsertServiceRequest,
  claims, type Claim, type InsertClaim,
  feedback, type Feedback, type InsertFeedback
} from "@shared/schema";

// Comprehensive storage interface for all the entities
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  
  // Task operations
  getTasks(): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  getTasksByUser(userId: number): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, task: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<boolean>;
  
  // Timesheet operations
  getTimesheets(): Promise<Timesheet[]>;
  getTimesheet(id: number): Promise<Timesheet | undefined>;
  getTimesheetsByUser(userId: number): Promise<Timesheet[]>;
  createTimesheet(timesheet: InsertTimesheet): Promise<Timesheet>;
  updateTimesheet(id: number, timesheet: Partial<InsertTimesheet>): Promise<Timesheet | undefined>;
  deleteTimesheet(id: number): Promise<boolean>;
  
  // Service Request operations
  getServiceRequests(): Promise<ServiceRequest[]>;
  getServiceRequest(id: number): Promise<ServiceRequest | undefined>;
  getServiceRequestsByUser(userId: number): Promise<ServiceRequest[]>;
  createServiceRequest(serviceRequest: InsertServiceRequest): Promise<ServiceRequest>;
  updateServiceRequest(id: number, serviceRequest: Partial<InsertServiceRequest>): Promise<ServiceRequest | undefined>;
  deleteServiceRequest(id: number): Promise<boolean>;
  
  // Claim operations
  getClaims(): Promise<Claim[]>;
  getClaim(id: number): Promise<Claim | undefined>;
  getClaimsByUser(userId: number): Promise<Claim[]>;
  createClaim(claim: InsertClaim): Promise<Claim>;
  updateClaim(id: number, claim: Partial<InsertClaim>): Promise<Claim | undefined>;
  deleteClaim(id: number): Promise<boolean>;
  
  // Feedback operations
  getFeedback(): Promise<Feedback[]>;
  getFeedbackById(id: number): Promise<Feedback | undefined>;
  getFeedbackByUser(userId: number): Promise<Feedback[]>;
  createFeedback(feedback: InsertFeedback): Promise<Feedback>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private usersDb: Map<number, User>;
  private tasksDb: Map<number, Task>;
  private timesheetsDb: Map<number, Timesheet>;
  private serviceRequestsDb: Map<number, ServiceRequest>;
  private claimsDb: Map<number, Claim>;
  private feedbackDb: Map<number, Feedback>;
  
  private userIdCounter: number;
  private taskIdCounter: number;
  private timesheetIdCounter: number;
  private serviceRequestIdCounter: number;
  private claimIdCounter: number;
  private feedbackIdCounter: number;
  
  constructor() {
    this.usersDb = new Map();
    this.tasksDb = new Map();
    this.timesheetsDb = new Map();
    this.serviceRequestsDb = new Map();
    this.claimsDb = new Map();
    this.feedbackDb = new Map();
    
    this.userIdCounter = 1;
    this.taskIdCounter = 1;
    this.timesheetIdCounter = 1;
    this.serviceRequestIdCounter = 1;
    this.claimIdCounter = 1;
    this.feedbackIdCounter = 1;
    
    // Initialize with one sample user for testing
    this.initializeDemoData();
  }
  
  // Initialize with demo data for testing
  private initializeDemoData() {
    // Add a demo user
    const demoUser: User = {
      id: this.userIdCounter++,
      username: "Anand Sharma",
      password: "Anand@338185",
      fullName: "Anand Sharma",
      email: "anand@tallitales.com",
      mobile: "9648338185",
      empCode: "500303",
      departmentId: 5,
      designationId: 96,
      dateOfJoining: "2024-11-06",
      gender: "M",
      profilePic: "",
      isAdmin: true, // Making the demo user an admin
      createdAt: new Date()
    };
    this.usersDb.set(demoUser.id, demoUser);
    
    // Add some demo tasks
    const demoTasks: InsertTask[] = [
      {
        title: "Complete monthly sales report",
        description: "Prepare and finalize the monthly sales report for management review",
        dueDate: "2025-04-23",
        priority: "High",
        status: "In Progress",
        assignedTo: demoUser.id,
        assignedBy: demoUser.id
      },
      {
        title: "Update product inventory database",
        description: "Ensure all product data is up-to-date in the inventory system",
        dueDate: "2025-04-25",
        priority: "Medium",
        status: "Not Started",
        assignedTo: demoUser.id,
        assignedBy: demoUser.id
      },
      {
        title: "Client follow-up calls",
        description: "Call all key accounts to follow up on recent orders",
        dueDate: "2025-04-21",
        priority: "High",
        status: "In Progress",
        assignedTo: demoUser.id,
        assignedBy: demoUser.id
      },
      {
        title: "Prepare presentation for quarterly review",
        description: "Create slides for the upcoming quarterly business review",
        dueDate: "2025-04-30",
        priority: "Low",
        status: "Not Started",
        assignedTo: demoUser.id,
        assignedBy: demoUser.id
      }
    ];
    
    demoTasks.forEach(task => {
      this.createTask(task);
    });
    
    // Add some demo service requests
    const demoServiceRequests: InsertServiceRequest[] = [
      {
        userId: demoUser.id,
        requestType: "IT Support",
        priority: "Medium",
        subject: "Laptop performance issues",
        description: "My laptop has been running slowly for the past week",
        status: "Open"
      },
      {
        userId: demoUser.id,
        requestType: "HR Query",
        priority: "Low",
        subject: "Leave policy clarification",
        description: "Need clarification on the new leave policy announced last month",
        status: "Pending"
      }
    ];
    
    demoServiceRequests.forEach(request => {
      this.createServiceRequest(request);
    });
    
    // Add some demo claims
    const demoClaims: InsertClaim[] = [
      {
        userId: demoUser.id,
        amount: 2500,
        category: "Travel",
        description: "Client meeting travel expenses",
        status: "Pending"
      },
      {
        userId: demoUser.id,
        amount: 1700,
        category: "Meals",
        description: "Client dinner",
        status: "In Process"
      }
    ];
    
    demoClaims.forEach(claim => {
      this.createClaim(claim);
    });
  }
  
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.usersDb.get(id);
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.usersDb.values()).find(
      (user) => user.username === username
    );
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.usersDb.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userUpdate: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.usersDb.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = { ...user, ...userUpdate };
    this.usersDb.set(id, updatedUser);
    return updatedUser;
  }
  
  // Task operations
  async getTasks(): Promise<Task[]> {
    return Array.from(this.tasksDb.values());
  }
  
  async getTask(id: number): Promise<Task | undefined> {
    return this.tasksDb.get(id);
  }
  
  async getTasksByUser(userId: number): Promise<Task[]> {
    return Array.from(this.tasksDb.values()).filter(
      task => task.assignedTo === userId
    );
  }
  
  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.taskIdCounter++;
    const task: Task = { ...insertTask, id, createdAt: new Date() };
    this.tasksDb.set(id, task);
    return task;
  }
  
  async updateTask(id: number, taskUpdate: Partial<InsertTask>): Promise<Task | undefined> {
    const task = this.tasksDb.get(id);
    if (!task) return undefined;
    
    const updatedTask: Task = { ...task, ...taskUpdate };
    this.tasksDb.set(id, updatedTask);
    return updatedTask;
  }
  
  async deleteTask(id: number): Promise<boolean> {
    return this.tasksDb.delete(id);
  }
  
  // Timesheet operations
  async getTimesheets(): Promise<Timesheet[]> {
    return Array.from(this.timesheetsDb.values());
  }
  
  async getTimesheet(id: number): Promise<Timesheet | undefined> {
    return this.timesheetsDb.get(id);
  }
  
  async getTimesheetsByUser(userId: number): Promise<Timesheet[]> {
    return Array.from(this.timesheetsDb.values()).filter(
      timesheet => timesheet.userId === userId
    );
  }
  
  async createTimesheet(insertTimesheet: InsertTimesheet): Promise<Timesheet> {
    const id = this.timesheetIdCounter++;
    const timesheet: Timesheet = { ...insertTimesheet, id, createdAt: new Date() };
    this.timesheetsDb.set(id, timesheet);
    return timesheet;
  }
  
  async updateTimesheet(id: number, timesheetUpdate: Partial<InsertTimesheet>): Promise<Timesheet | undefined> {
    const timesheet = this.timesheetsDb.get(id);
    if (!timesheet) return undefined;
    
    const updatedTimesheet: Timesheet = { ...timesheet, ...timesheetUpdate };
    this.timesheetsDb.set(id, updatedTimesheet);
    return updatedTimesheet;
  }
  
  async deleteTimesheet(id: number): Promise<boolean> {
    return this.timesheetsDb.delete(id);
  }
  
  // Service Request operations
  async getServiceRequests(): Promise<ServiceRequest[]> {
    return Array.from(this.serviceRequestsDb.values());
  }
  
  async getServiceRequest(id: number): Promise<ServiceRequest | undefined> {
    return this.serviceRequestsDb.get(id);
  }
  
  async getServiceRequestsByUser(userId: number): Promise<ServiceRequest[]> {
    return Array.from(this.serviceRequestsDb.values()).filter(
      request => request.userId === userId
    );
  }
  
  async createServiceRequest(insertServiceRequest: InsertServiceRequest): Promise<ServiceRequest> {
    const id = this.serviceRequestIdCounter++;
    const serviceRequest: ServiceRequest = { ...insertServiceRequest, id, createdAt: new Date() };
    this.serviceRequestsDb.set(id, serviceRequest);
    return serviceRequest;
  }
  
  async updateServiceRequest(id: number, serviceRequestUpdate: Partial<InsertServiceRequest>): Promise<ServiceRequest | undefined> {
    const serviceRequest = this.serviceRequestsDb.get(id);
    if (!serviceRequest) return undefined;
    
    const updatedServiceRequest: ServiceRequest = { ...serviceRequest, ...serviceRequestUpdate };
    this.serviceRequestsDb.set(id, updatedServiceRequest);
    return updatedServiceRequest;
  }
  
  async deleteServiceRequest(id: number): Promise<boolean> {
    return this.serviceRequestsDb.delete(id);
  }
  
  // Claim operations
  async getClaims(): Promise<Claim[]> {
    return Array.from(this.claimsDb.values());
  }
  
  async getClaim(id: number): Promise<Claim | undefined> {
    return this.claimsDb.get(id);
  }
  
  async getClaimsByUser(userId: number): Promise<Claim[]> {
    return Array.from(this.claimsDb.values()).filter(
      claim => claim.userId === userId
    );
  }
  
  async createClaim(insertClaim: InsertClaim): Promise<Claim> {
    const id = this.claimIdCounter++;
    const claim: Claim = { ...insertClaim, id, createdAt: new Date() };
    this.claimsDb.set(id, claim);
    return claim;
  }
  
  async updateClaim(id: number, claimUpdate: Partial<InsertClaim>): Promise<Claim | undefined> {
    const claim = this.claimsDb.get(id);
    if (!claim) return undefined;
    
    const updatedClaim: Claim = { ...claim, ...claimUpdate };
    this.claimsDb.set(id, updatedClaim);
    return updatedClaim;
  }
  
  async deleteClaim(id: number): Promise<boolean> {
    return this.claimsDb.delete(id);
  }
  
  // Feedback operations
  async getFeedback(): Promise<Feedback[]> {
    return Array.from(this.feedbackDb.values());
  }
  
  async getFeedbackById(id: number): Promise<Feedback | undefined> {
    return this.feedbackDb.get(id);
  }
  
  async getFeedbackByUser(userId: number): Promise<Feedback[]> {
    return Array.from(this.feedbackDb.values()).filter(
      feedback => feedback.userId === userId
    );
  }
  
  async createFeedback(insertFeedback: InsertFeedback): Promise<Feedback> {
    const id = this.feedbackIdCounter++;
    const feedbackEntry: Feedback = { ...insertFeedback, id, createdAt: new Date() };
    this.feedbackDb.set(id, feedbackEntry);
    return feedbackEntry;
  }
}

export const storage = new MemStorage();
