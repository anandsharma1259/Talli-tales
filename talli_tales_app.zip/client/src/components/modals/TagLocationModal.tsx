import { useState, useEffect } from "react";

interface TagLocationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const TagLocationModal = ({ isOpen, onClose }: TagLocationModalProps) => {
  const [locationAddress, setLocationAddress] = useState("Fetching your location...");
  const [locationCoordinates, setLocationCoordinates] = useState("");
  const [remarks, setRemarks] = useState("");
  
  const refreshLocation = () => {
    setLocationAddress("Fetching your location...");
    setLocationCoordinates("");
    
    // Simulate location fetching
    setTimeout(() => {
      setLocationAddress("Talli Tales Office, Sector 44, Gurugram");
      setLocationCoordinates("28.4595° N, 77.0266° E");
    }, 1500);
  };
  
  useEffect(() => {
    if (isOpen) {
      refreshLocation();
    }
  }, [isOpen]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real application, this would send data to the server
    console.log({
      locationAddress,
      locationCoordinates,
      remarks
    });
    
    // Clear form
    setRemarks("");
    
    onClose();
  };
  
  return (
    <div className={`fixed inset-0 bg-black/50 z-50 ${isOpen ? 'flex' : 'hidden'} items-center justify-center`}>
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4">
        <div className="flex justify-between items-center p-6 border-b border-neutral-200">
          <h3 className="text-lg font-bold">Tag Your Location</h3>
          <button 
            className="text-neutral-500 hover:text-neutral-700"
            onClick={onClose}
          >
            <i className="fas fa-times"></i>
          </button>
        </div>
        
        <div className="p-6">
          <div className="bg-primary/10 rounded-md p-4 mb-4">
            <div className="flex items-center">
              <i className="fas fa-info-circle text-primary mr-3"></i>
              <p className="text-sm text-neutral-700">
                Tagging your location helps us record your attendance accurately. Please ensure you are at your work location when tagging.
              </p>
            </div>
          </div>
          
          <div className="bg-neutral-100 rounded-md p-4 mb-4 h-40 flex items-center justify-center">
            <div className="text-center">
              <i className="fas fa-map-marker-alt text-danger text-2xl mb-2"></i>
              <p className="text-sm text-neutral-700">Map Will Appear Here</p>
              <p className="text-xs text-neutral-500">Please allow location access when prompted</p>
            </div>
          </div>
          
          <div className="mb-4">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-success/20 rounded-full flex items-center justify-center mr-4">
                <i className="fas fa-map-marker-alt text-success text-xl"></i>
              </div>
              <div>
                <p className="font-medium">{locationAddress}</p>
                <p className="text-sm text-neutral-500">{locationCoordinates}</p>
              </div>
            </div>
          </div>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="location-remarks" className="block text-sm font-medium text-neutral-700 mb-1">
                Remarks (Optional)
              </label>
              <textarea 
                id="location-remarks" 
                rows={2} 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary" 
                placeholder="Any additional information about your location"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
              />
            </div>
            
            <div className="flex justify-end space-x-3 pt-6 border-t border-neutral-200 mt-4">
              <button 
                type="button"
                className="px-4 py-2 border border-neutral-300 rounded-md text-neutral-700 hover:bg-neutral-50"
                onClick={onClose}
              >
                Cancel
              </button>
              <button 
                type="button"
                className="px-4 py-2 border border-primary text-primary rounded-md hover:bg-primary/10"
                onClick={refreshLocation}
              >
                <i className="fas fa-sync-alt mr-1"></i> Refresh
              </button>
              <button 
                type="submit"
                className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
              >
                Tag Location
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default TagLocationModal;
