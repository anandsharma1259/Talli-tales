import { useState } from "react";

interface AddTimesheetModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AddTimesheetModal = ({ isOpen, onClose }: AddTimesheetModalProps) => {
  const [date, setDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [project, setProject] = useState("");
  const [task, setTask] = useState("");
  const [description, setDescription] = useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real application, this would send data to the server
    console.log({
      date,
      startTime,
      endTime,
      project,
      task,
      description
    });
    
    // Clear form
    setDate("");
    setStartTime("");
    setEndTime("");
    setProject("");
    setTask("");
    setDescription("");
    
    onClose();
  };
  
  return (
    <div className={`fixed inset-0 bg-black/50 z-50 ${isOpen ? 'flex' : 'hidden'} items-center justify-center`}>
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4">
        <div className="flex justify-between items-center p-6 border-b border-neutral-200">
          <h3 className="text-lg font-bold">Add Timesheet Entry</h3>
          <button 
            className="text-neutral-500 hover:text-neutral-700"
            onClick={onClose}
          >
            <i className="fas fa-times"></i>
          </button>
        </div>
        
        <div className="p-6">
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="timesheet-date" className="block text-sm font-medium text-neutral-700 mb-1">
                Date
              </label>
              <input 
                type="date" 
                id="timesheet-date" 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="timesheet-start-time" className="block text-sm font-medium text-neutral-700 mb-1">
                  Start Time
                </label>
                <input 
                  type="time" 
                  id="timesheet-start-time" 
                  className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  required
                />
              </div>
              
              <div>
                <label htmlFor="timesheet-end-time" className="block text-sm font-medium text-neutral-700 mb-1">
                  End Time
                </label>
                <input 
                  type="time" 
                  id="timesheet-end-time" 
                  className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  required
                />
              </div>
            </div>
            
            <div className="mb-4">
              <label htmlFor="timesheet-project" className="block text-sm font-medium text-neutral-700 mb-1">
                Project
              </label>
              <select 
                id="timesheet-project" 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary"
                value={project}
                onChange={(e) => setProject(e.target.value)}
                required
              >
                <option value="">Select Project</option>
                <option value="tallibevs-distribution">TalliBevs Distribution</option>
                <option value="tallibevs-retail">TalliBevs Retail</option>
                <option value="premium-collection">Premium Collection Launch</option>
              </select>
            </div>
            
            <div className="mb-4">
              <label htmlFor="timesheet-task" className="block text-sm font-medium text-neutral-700 mb-1">
                Task
              </label>
              <select 
                id="timesheet-task" 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary"
                value={task}
                onChange={(e) => setTask(e.target.value)}
                required
              >
                <option value="">Select Task</option>
                <option value="sales">Sales Activities</option>
                <option value="meetings">Client Meetings</option>
                <option value="reporting">Reporting</option>
                <option value="admin">Administrative Tasks</option>
              </select>
            </div>
            
            <div className="mb-4">
              <label htmlFor="timesheet-description" className="block text-sm font-medium text-neutral-700 mb-1">
                Description
              </label>
              <textarea 
                id="timesheet-description" 
                rows={3} 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary" 
                placeholder="Enter brief description of work done"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
            
            <div className="flex justify-end space-x-3 pt-6 border-t border-neutral-200 mt-4">
              <button 
                type="button"
                className="px-4 py-2 border border-neutral-300 rounded-md text-neutral-700 hover:bg-neutral-50"
                onClick={onClose}
              >
                Cancel
              </button>
              <button 
                type="submit"
                className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
              >
                Submit
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddTimesheetModal;
