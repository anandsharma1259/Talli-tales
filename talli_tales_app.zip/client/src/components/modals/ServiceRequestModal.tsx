import { useState } from "react";

interface ServiceRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ServiceRequestModal = ({ isOpen, onClose }: ServiceRequestModalProps) => {
  const [requestType, setRequestType] = useState("");
  const [priority, setPriority] = useState("medium");
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real application, this would send data to the server
    console.log({
      requestType,
      priority,
      subject,
      description
    });
    
    // Clear form
    setRequestType("");
    setPriority("medium");
    setSubject("");
    setDescription("");
    
    onClose();
  };
  
  return (
    <div className={`fixed inset-0 bg-black/50 z-50 ${isOpen ? 'flex' : 'hidden'} items-center justify-center`}>
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4">
        <div className="flex justify-between items-center p-6 border-b border-neutral-200">
          <h3 className="text-lg font-bold">Open Service Request</h3>
          <button 
            className="text-neutral-500 hover:text-neutral-700"
            onClick={onClose}
          >
            <i className="fas fa-times"></i>
          </button>
        </div>
        
        <div className="p-6">
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="request-type" className="block text-sm font-medium text-neutral-700 mb-1">
                Request Type
              </label>
              <select 
                id="request-type" 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary"
                value={requestType}
                onChange={(e) => setRequestType(e.target.value)}
                required
              >
                <option value="">Select Request Type</option>
                <option value="it-support">IT Support</option>
                <option value="hr-query">HR Query</option>
                <option value="payroll">Payroll</option>
                <option value="leave">Leave Application</option>
                <option value="equipment">Equipment Request</option>
              </select>
            </div>
            
            <div className="mb-4">
              <label htmlFor="request-priority" className="block text-sm font-medium text-neutral-700 mb-1">
                Priority
              </label>
              <select 
                id="request-priority" 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary"
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
            
            <div className="mb-4">
              <label htmlFor="request-subject" className="block text-sm font-medium text-neutral-700 mb-1">
                Subject
              </label>
              <input 
                type="text" 
                id="request-subject" 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary" 
                placeholder="Enter brief subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="request-description" className="block text-sm font-medium text-neutral-700 mb-1">
                Description
              </label>
              <textarea 
                id="request-description" 
                rows={4} 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary" 
                placeholder="Describe your request in detail"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              />
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium text-neutral-700 mb-1">
                Attachments (Optional)
              </label>
              <div className="border border-dashed border-neutral-300 rounded-md p-4 flex items-center justify-center">
                <div className="text-center">
                  <i className="fas fa-cloud-upload-alt text-2xl text-neutral-400 mb-2"></i>
                  <p className="text-sm text-neutral-500">Drag & drop files here or</p>
                  <button 
                    type="button" 
                    className="mt-2 px-3 py-1 bg-primary/10 text-primary text-sm rounded-md hover:bg-primary/20"
                  >
                    Browse Files
                  </button>
                  <input type="file" className="hidden" multiple />
                </div>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3 pt-6 border-t border-neutral-200 mt-4">
              <button 
                type="button"
                className="px-4 py-2 border border-neutral-300 rounded-md text-neutral-700 hover:bg-neutral-50"
                onClick={onClose}
              >
                Cancel
              </button>
              <button 
                type="submit"
                className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
              >
                Submit Request
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ServiceRequestModal;
