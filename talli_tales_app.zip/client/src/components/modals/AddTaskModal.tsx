import { useState } from "react";
import { Dialog } from "@/components/ui/dialog";

interface AddTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AddTaskModal = ({ isOpen, onClose }: AddTaskModalProps) => {
  const [taskTitle, setTaskTitle] = useState("");
  const [taskDescription, setTaskDescription] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [priority, setPriority] = useState("low");
  const [assignTo, setAssignTo] = useState("self");
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real application, this would send data to the server
    console.log({
      taskTitle,
      taskDescription,
      dueDate,
      priority,
      assignTo
    });
    
    // Clear form
    setTaskTitle("");
    setTaskDescription("");
    setDueDate("");
    setPriority("low");
    setAssignTo("self");
    
    onClose();
  };
  
  return (
    <div className={`fixed inset-0 bg-black/50 z-50 ${isOpen ? 'flex' : 'hidden'} items-center justify-center`}>
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-4">
        <div className="flex justify-between items-center p-6 border-b border-neutral-200">
          <h3 className="text-lg font-bold">Add New Task</h3>
          <button 
            className="text-neutral-500 hover:text-neutral-700"
            onClick={onClose}
          >
            <i className="fas fa-times"></i>
          </button>
        </div>
        
        <div className="p-6">
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="task-title" className="block text-sm font-medium text-neutral-700 mb-1">
                Task Title
              </label>
              <input 
                type="text" 
                id="task-title" 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary" 
                placeholder="Enter task title"
                value={taskTitle}
                onChange={(e) => setTaskTitle(e.target.value)}
                required
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="task-description" className="block text-sm font-medium text-neutral-700 mb-1">
                Description
              </label>
              <textarea 
                id="task-description" 
                rows={3} 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary" 
                placeholder="Enter task description"
                value={taskDescription}
                onChange={(e) => setTaskDescription(e.target.value)}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label htmlFor="task-due-date" className="block text-sm font-medium text-neutral-700 mb-1">
                  Due Date
                </label>
                <input 
                  type="date" 
                  id="task-due-date" 
                  className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  required
                />
              </div>
              
              <div>
                <label htmlFor="task-priority" className="block text-sm font-medium text-neutral-700 mb-1">
                  Priority
                </label>
                <select 
                  id="task-priority" 
                  className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary"
                  value={priority}
                  onChange={(e) => setPriority(e.target.value)}
                >
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </div>
            </div>
            
            <div className="mb-4">
              <label htmlFor="task-assignee" className="block text-sm font-medium text-neutral-700 mb-1">
                Assign To
              </label>
              <select 
                id="task-assignee" 
                className="w-full border border-neutral-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary"
                value={assignTo}
                onChange={(e) => setAssignTo(e.target.value)}
              >
                <option value="self">Myself</option>
                <option value="team">Team Member</option>
              </select>
            </div>
            
            <div className="flex justify-end space-x-3 pt-6 border-t border-neutral-200 mt-4">
              <button 
                type="button"
                className="px-4 py-2 border border-neutral-300 rounded-md text-neutral-700 hover:bg-neutral-50"
                onClick={onClose}
              >
                Cancel
              </button>
              <button 
                type="submit"
                className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90"
              >
                Add Task
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddTaskModal;
