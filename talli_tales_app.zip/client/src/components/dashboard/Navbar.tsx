import { useState, useRef, useEffect } from "react";
import { Link } from "wouter";

interface NavbarProps {
  toggleSidebar: () => void;
  openModal: (modalId: string) => void;
}

const Navbar = ({ toggleSidebar, openModal }: NavbarProps) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  
  const notificationsRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
        setNotificationsOpen(false);
      }
      
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setUserMenuOpen(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto">
        <div className="flex justify-between items-center py-3">
          {/* Logo Section */}
          <div className="flex items-center space-x-4">
            <button 
              id="sidebar-toggle" 
              className="p-2 rounded-md lg:hidden hover:bg-neutral-100"
              onClick={toggleSidebar}
            >
              <i className="fas fa-bars text-primary"></i>
            </button>
            <Link href="/" className="flex items-center">
              <div className="h-10 flex items-center justify-center bg-primary text-white font-bold px-3 rounded">
                Talli Tales
              </div>
            </Link>
          </div>
          
          {/* Main Navigation - Desktop */}
          <div className="hidden lg:flex items-center space-x-6">
            <Link href="/" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              Home
            </Link>
            
            {/* Quick Actions Dropdown */}
            <div className="relative group">
              <button className="flex items-center text-neutral-700 hover:text-primary transition-colors font-medium">
                Quick Actions <i className="fas fa-chevron-down ml-1 text-xs"></i>
              </button>
              <div className="absolute left-0 mt-2 w-56 bg-white shadow-lg rounded-md py-2 z-10 hidden group-hover:block">
                <button 
                  onClick={() => openModal('add-task-modal')}
                  className="block w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white"
                >
                  Add Task
                </button>
                <button 
                  onClick={() => openModal('add-timesheet-modal')}
                  className="block w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white"
                >
                  Add Timesheet
                </button>
                <button 
                  onClick={() => openModal('service-request-modal')}
                  className="block w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white"
                >
                  Open Service Request
                </button>
                <Link href="/user/submit-claim/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white">
                  Submit Claim
                </Link>
                <Link href="/attendance/forget-tag/" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white">
                  Forgot Geo Tag
                </Link>
              </div>
            </div>
            
            {/* Media & Web Dropdown */}
            <div className="relative group">
              <button className="flex items-center text-neutral-700 hover:text-primary transition-colors font-medium">
                Media & Web <i className="fas fa-chevron-down ml-1 text-xs"></i>
              </button>
              <div className="absolute left-0 mt-2 w-56 bg-white shadow-lg rounded-md py-2 z-10 hidden group-hover:block">
                <div className="relative group/sub">
                  <div className="flex justify-between items-center px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white">
                    Company Websites
                    <i className="fas fa-chevron-right text-xs"></i>
                  </div>
                  <div className="absolute left-full top-0 w-56 bg-white shadow-lg rounded-md py-2 z-10 hidden group-hover/sub:block">
                    <a href="https://tallitales.com" target="_blank" rel="noopener noreferrer" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white">
                      <i className="fas fa-angle-right mr-2"></i> Talli Tales Distribution
                    </a>
                    <a href="https://tallibevs.com" target="_blank" rel="noopener noreferrer" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white">
                      <i className="fas fa-angle-right mr-2"></i> TalliBevs
                    </a>
                  </div>
                </div>
                <a href="https://play.google.com/store" target="_blank" rel="noopener noreferrer" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white">
                  TalliBevs Android Link
                </a>
                <a href="https://apps.apple.com" target="_blank" rel="noopener noreferrer" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white">
                  TalliBevs iOS Link
                </a>
              </div>
            </div>
            
            <Link href="/dashboard/our-products" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              Our Products
            </Link>
            <Link href="/dashboard/our-offices" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              Our Offices
            </Link>
            <Link href="/module/add-feedback" className="text-neutral-700 hover:text-primary transition-colors font-medium">
              Feedback
            </Link>
          </div>
          
          {/* User Menu */}
          <div className="flex items-center space-x-4">
            {/* Notifications */}
            <div className="relative" ref={notificationsRef}>
              <button 
                className="flex items-center text-neutral-700 hover:text-primary transition-colors"
                onClick={() => setNotificationsOpen(!notificationsOpen)}
              >
                <div className="relative">
                  <i className="fas fa-bell text-xl"></i>
                  <span className="absolute -top-1 -right-1 bg-danger text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                    3
                  </span>
                </div>
              </button>
              
              {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white shadow-lg rounded-md py-2 z-10">
                  <div className="px-4 py-2 border-b border-neutral-200">
                    <h5 className="font-medium">Notifications</h5>
                  </div>
                  
                  <div className="max-h-80 overflow-y-auto">
                    <a href="#" className="block px-4 py-3 hover:bg-neutral-100 border-b border-neutral-200">
                      <div className="flex">
                        <div className="flex-shrink-0 mr-3">
                          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                            <i className="fas fa-tasks text-primary"></i>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm font-medium">New task assigned</p>
                          <p className="text-xs text-neutral-500">2 hours ago</p>
                        </div>
                      </div>
                    </a>
                    
                    <a href="#" className="block px-4 py-3 hover:bg-neutral-100 border-b border-neutral-200">
                      <div className="flex">
                        <div className="flex-shrink-0 mr-3">
                          <div className="w-10 h-10 rounded-full bg-info/20 flex items-center justify-center">
                            <i className="fas fa-comment text-info"></i>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Your leave request was approved</p>
                          <p className="text-xs text-neutral-500">5 hours ago</p>
                        </div>
                      </div>
                    </a>
                    
                    <a href="#" className="block px-4 py-3 hover:bg-neutral-100">
                      <div className="flex">
                        <div className="flex-shrink-0 mr-3">
                          <div className="w-10 h-10 rounded-full bg-warning/20 flex items-center justify-center">
                            <i className="fas fa-clock text-warning"></i>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm font-medium">Timesheet reminder</p>
                          <p className="text-xs text-neutral-500">Yesterday</p>
                        </div>
                      </div>
                    </a>
                  </div>
                  
                  <div className="px-4 py-2 border-t border-neutral-200">
                    <a href="/notifications" className="text-primary text-sm hover:underline">
                      View all notifications
                    </a>
                  </div>
                </div>
              )}
            </div>
            
            {/* User Profile */}
            <div className="relative" ref={userMenuRef}>
              <button 
                className="flex items-center space-x-2"
                onClick={() => setUserMenuOpen(!userMenuOpen)}
              >
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary">
                  <i className="fas fa-user"></i>
                </div>
                <span className="text-sm font-medium text-neutral-700 hidden md:inline-block">
                  Anand Sharma
                </span>
                <i className="fas fa-chevron-down text-xs"></i>
              </button>
              
              {userMenuOpen && (
                <div className="absolute right-0 mt-2 w-56 bg-white shadow-lg rounded-md py-2 z-10">
                  <div className="px-4 py-3 border-b border-neutral-200">
                    <p className="text-sm font-medium">Anand Sharma</p>
                    <p className="text-xs text-neutral-500">Individual Contributor</p>
                    <p className="text-xs text-neutral-500">Sales</p>
                  </div>
                  
                  <Link href="/profile" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white">
                    <i className="fas fa-user mr-2"></i> My Profile
                  </Link>
                  
                  <Link href="/settings" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white">
                    <i className="fas fa-cog mr-2"></i> Settings
                  </Link>
                  
                  <Link href="/admin" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white">
                    <i className="fas fa-shield-alt mr-2"></i> Admin Dashboard
                  </Link>
                  
                  <button 
                    onClick={() => openModal('tag-location-modal')}
                    className="block w-full text-left px-4 py-2 text-sm text-neutral-700 hover:bg-primary hover:text-white"
                  >
                    <i className="fas fa-map-marker-alt mr-2"></i> Tag Location
                  </button>
                  
                  <div className="border-t border-neutral-200 my-1"></div>
                  
                  <Link href="/logout" className="block px-4 py-2 text-sm text-neutral-700 hover:bg-danger hover:text-white">
                    <i className="fas fa-sign-out-alt mr-2"></i> Logout
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile Navigation Menu */}
      <div className={`lg:hidden bg-white border-t border-neutral-200 py-2 ${mobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="container mx-auto px-4">
          <Link href="/" className="block py-2 text-neutral-700 hover:text-primary">
            Home
          </Link>
          
          <div className="py-2">
            <button 
              className="flex items-center justify-between w-full py-2 text-neutral-700 hover:text-primary"
              onClick={() => {}}
            >
              <span>Quick Actions</span>
              <i className="fas fa-chevron-down text-xs"></i>
            </button>
            <div className="pl-4 space-y-1 mt-1">
              <button 
                onClick={() => openModal('add-task-modal')}
                className="block py-2 text-neutral-700 hover:text-primary"
              >
                Add Task
              </button>
              <button 
                onClick={() => openModal('add-timesheet-modal')}
                className="block py-2 text-neutral-700 hover:text-primary"
              >
                Add Timesheet
              </button>
              <button 
                onClick={() => openModal('service-request-modal')}
                className="block py-2 text-neutral-700 hover:text-primary"
              >
                Open Service Request
              </button>
              <Link href="/user/submit-claim/" className="block py-2 text-neutral-700 hover:text-primary">
                Submit Claim
              </Link>
              <Link href="/attendance/forget-tag/" className="block py-2 text-neutral-700 hover:text-primary">
                Forgot Geo Tag
              </Link>
            </div>
          </div>
          
          <div className="py-2">
            <button 
              className="flex items-center justify-between w-full py-2 text-neutral-700 hover:text-primary"
              onClick={() => {}}
            >
              <span>Media & Web</span>
              <i className="fas fa-chevron-down text-xs"></i>
            </button>
            <div className="pl-4 space-y-1 mt-1">
              <div className="py-2">
                <button 
                  className="flex items-center justify-between w-full py-2 text-neutral-700 hover:text-primary"
                  onClick={() => {}}
                >
                  <span>Company Websites</span>
                  <i className="fas fa-chevron-down text-xs"></i>
                </button>
                <div className="pl-4 space-y-1 mt-1">
                  <a href="https://tallitales.com" target="_blank" rel="noopener noreferrer" className="block py-2 text-neutral-700 hover:text-primary">
                    Talli Tales Distribution
                  </a>
                  <a href="https://tallibevs.com" target="_blank" rel="noopener noreferrer" className="block py-2 text-neutral-700 hover:text-primary">
                    TalliBevs
                  </a>
                </div>
              </div>
              <a href="https://play.google.com/store" target="_blank" rel="noopener noreferrer" className="block py-2 text-neutral-700 hover:text-primary">
                TalliBevs Android Link
              </a>
              <a href="https://apps.apple.com" target="_blank" rel="noopener noreferrer" className="block py-2 text-neutral-700 hover:text-primary">
                TalliBevs iOS Link
              </a>
            </div>
          </div>
          
          <Link href="/dashboard/our-products/" className="block py-2 text-neutral-700 hover:text-primary">
            Our Products
          </Link>
          <Link href="/dashboard/our-offices/" className="block py-2 text-neutral-700 hover:text-primary">
            Our Offices
          </Link>
          <Link href="/module/add-feedback/" className="block py-2 text-neutral-700 hover:text-primary">
            Feedback
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
