import { Link } from "wouter";

interface Holiday {
  id: number;
  name: string;
  date: {
    day: number;
    month: string;
    dayOfWeek: string;
  };
  daysLeft: number;
}

const UpcomingHolidays = () => {
  // Sample holidays data for demonstration
  const holidays: Holiday[] = [
    {
      id: 1,
      name: "Labor Day",
      date: {
        day: 1,
        month: "MAY",
        dayOfWeek: "Thursday"
      },
      daysLeft: 10
    },
    {
      id: 2,
      name: "Buddha Purnima",
      date: {
        day: 23,
        month: "MAY",
        dayOfWeek: "Friday"
      },
      daysLeft: 32
    },
    {
      id: 3,
      name: "Eid al-Adha",
      date: {
        day: 17,
        month: "JUN",
        dayOfWeek: "Tuesday"
      },
      daysLeft: 57
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6 border-b border-neutral-200">
        <h3 className="text-lg font-bold">Upcoming Holidays</h3>
      </div>
      
      <div className="p-0">
        {holidays.map((holiday, index) => (
          <div 
            key={holiday.id}
            className={`flex items-center p-4 ${index < holidays.length - 1 ? 'border-b border-neutral-100' : ''}`}
          >
            <div className="mr-4 flex-shrink-0">
              <div className="w-12 h-12 rounded-lg bg-danger/10 flex flex-col items-center justify-center">
                <span className="text-xs font-bold text-danger">{holiday.date.month}</span>
                <span className="text-lg font-bold text-danger">{holiday.date.day}</span>
              </div>
            </div>
            <div>
              <h4 className="font-medium">{holiday.name}</h4>
              <p className="text-sm text-neutral-500">{holiday.date.dayOfWeek}</p>
            </div>
            <div className="ml-auto">
              <span className="text-xs px-2 py-1 bg-danger/10 text-danger rounded-full">
                {holiday.daysLeft} days left
              </span>
            </div>
          </div>
        ))}
      </div>
      
      <div className="p-4 border-t border-neutral-200">
        <Link href="/holiday-calendar" className="text-primary hover:underline text-sm">
          View all holidays
        </Link>
      </div>
    </div>
  );
};

export default UpcomingHolidays;
