import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Download, Loader } from "lucide-react";

const DownloadAppButton = () => {
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = () => {
    setIsDownloading(true);
    
    // Create a temporary anchor to download the file
    const link = document.createElement('a');
    link.href = '/api/download';
    link.setAttribute('download', 'talli_tales_app.zip');
    document.body.appendChild(link);
    link.click();
    
    // Clean up after download starts
    setTimeout(() => {
      document.body.removeChild(link);
      setIsDownloading(false);
    }, 5000);
  };

  return (
    <Button 
      onClick={handleDownload}
      disabled={isDownloading}
      className="w-full"
      variant="outline"
    >
      {isDownloading ? (
        <>
          <Loader className="h-4 w-4 animate-spin mr-2" />
          Downloading...
        </>
      ) : (
        <>
          <Download className="h-4 w-4 mr-2" />
          Download Application
        </>
      )}
    </Button>
  );
};

export default DownloadAppButton;