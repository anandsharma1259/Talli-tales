interface Announcement {
  id: number;
  title: string;
  content: string;
  date: string;
  author: string;
  icon: string;
  iconBgColor: string;
  iconColor: string;
}

const Announcements = () => {
  // Sample announcements for demonstration
  const announcements: Announcement[] = [
    {
      id: 1,
      title: "Quarterly Team Meeting",
      content: "All team members are required to attend the quarterly meeting on April 25th at 10:00 AM. The agenda will include sales targets, new product launches, and strategic initiatives for Q2.",
      date: "Apr 18, 2025",
      author: "Admin",
      icon: "fas fa-bullhorn",
      iconBgColor: "bg-primary/20",
      iconColor: "text-primary"
    },
    {
      id: 2,
      title: "New Product Launch: TalliBevs Premium Collection",
      content: "We're excited to announce the upcoming launch of our new premium spirits collection next month. Training sessions will be scheduled for all sales representatives.",
      date: "Apr 15, 2025",
      author: "Product Team",
      icon: "fas fa-glass-cheers",
      iconBgColor: "bg-info/20",
      iconColor: "text-info"
    },
    {
      id: 3,
      title: "Employee Recognition: Top Performers Q1",
      content: "Congratulations to Rohit Singh, Priya Mehta, and Vikram Doshi for their outstanding sales performance in Q1. They will be recognized at the quarterly meeting.",
      date: "Apr 10, 2025",
      author: "HR Team",
      icon: "fas fa-award",
      iconBgColor: "bg-success/20",
      iconColor: "text-success"
    }
  ];

  return (
    <div className="mt-6 bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6 border-b border-neutral-200">
        <h3 className="text-lg font-bold">Announcements & Updates</h3>
      </div>
      
      <div className="p-0">
        {announcements.map((announcement, index) => (
          <div 
            key={announcement.id}
            className={`p-6 ${index < announcements.length - 1 ? 'border-b border-neutral-100' : ''}`}
          >
            <div className="flex">
              <div className="flex-shrink-0 mr-4">
                <div className={`h-12 w-12 rounded-full ${announcement.iconBgColor} flex items-center justify-center`}>
                  <i className={`${announcement.icon} ${announcement.iconColor}`}></i>
                </div>
              </div>
              <div>
                <h4 className="text-base font-medium">{announcement.title}</h4>
                <p className="text-sm text-neutral-600 mt-1">{announcement.content}</p>
                <div className="mt-2 flex items-center text-sm text-neutral-500">
                  <span>{announcement.date}</span>
                  <span className="mx-2">•</span>
                  <span>{announcement.author}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Announcements;
