import { Link } from "wouter";

interface Task {
  id: number;
  title: string;
  assignedBy: string;
  dueDate: string;
  daysLeft: number | string;
  priority: 'High' | 'Medium' | 'Low';
  status: 'Not Started' | 'In Progress' | 'Completed';
}

const TaskList = () => {
  // Sample tasks for demonstration
  const tasks: Task[] = [
    {
      id: 1,
      title: "Complete monthly sales report",
      assignedBy: "Rajesh Kumar",
      dueDate: "Apr 23, 2025",
      daysLeft: "2 days left",
      priority: "High",
      status: "In Progress"
    },
    {
      id: 2,
      title: "Update product inventory database",
      assignedBy: "Neha Sharma",
      dueDate: "Apr 25, 2025",
      daysLeft: "4 days left",
      priority: "Medium",
      status: "Not Started"
    },
    {
      id: 3,
      title: "Client follow-up calls",
      assignedBy: "Self",
      dueDate: "Apr 21, 2025",
      daysLeft: "Today",
      priority: "High",
      status: "In Progress"
    },
    {
      id: 4,
      title: "Prepare presentation for quarterly review",
      assignedBy: "Amit Patel",
      dueDate: "Apr 30, 2025",
      daysLeft: "9 days left",
      priority: "Low",
      status: "Not Started"
    }
  ];

  const getPriorityClasses = (priority: string) => {
    switch (priority) {
      case 'High':
        return 'bg-danger/20 text-danger';
      case 'Medium':
        return 'bg-warning/20 text-warning';
      case 'Low':
        return 'bg-info/20 text-info';
      default:
        return 'bg-neutral-200 text-neutral-700';
    }
  };

  const getStatusClasses = (status: string) => {
    switch (status) {
      case 'Completed':
        return 'bg-success/20 text-success';
      case 'In Progress':
        return 'bg-warning/20 text-warning';
      case 'Not Started':
      default:
        return 'bg-neutral-200 text-neutral-700';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md">
      <div className="p-6 border-b border-neutral-200">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-bold">My Tasks</h3>
          <button className="text-primary hover:underline text-sm" onClick={() => {}}>
            <i className="fas fa-plus mr-1"></i> Add New
          </button>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-neutral-50">
              <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Task</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Due Date</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Priority</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-200">
            {tasks.map((task) => (
              <tr key={task.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-neutral-900">{task.title}</div>
                  <div className="text-xs text-neutral-500">Assigned by: {task.assignedBy}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-neutral-700">{task.dueDate}</div>
                  <div className="text-xs text-danger">{task.daysLeft}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityClasses(task.priority)}`}>
                    {task.priority}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusClasses(task.status)}`}>
                    {task.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-500">
                  <button className="text-primary hover:text-primary/80 mr-3">
                    <i className="fas fa-eye"></i>
                  </button>
                  <button className="text-success hover:text-success/80">
                    <i className="fas fa-check"></i>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      <div className="p-4 border-t border-neutral-200 flex justify-between items-center">
        <p className="text-sm text-neutral-500">Showing {tasks.length} of 7 tasks</p>
        <Link href="/tasks" className="text-primary hover:underline text-sm">View all tasks</Link>
      </div>
    </div>
  );
};

export default TaskList;
