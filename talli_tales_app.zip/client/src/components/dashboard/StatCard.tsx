import { Link } from "wouter";

interface StatCardProps {
  title: string;
  value: string | number;
  change?: string;
  status?: string;
  icon: string;
  iconBgColor: string;
  iconColor: string;
  linkText: string;
  linkHref: string;
  linkColor: string;
}

const StatCard = ({ 
  title, 
  value, 
  change, 
  status,
  icon, 
  iconBgColor, 
  iconColor, 
  linkText, 
  linkHref,
  linkColor
}: StatCardProps) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-neutral-500 text-sm">{title}</p>
          <h2 className="text-3xl font-bold mt-1">{value}</h2>
          <p className="text-sm mt-3">
            {change && <span className={linkColor}>{change}</span>}
            {status && <span> {status}</span>}
          </p>
        </div>
        <div className={`${iconBgColor} p-3 rounded-full`}>
          <i className={`${icon} ${iconColor} text-xl`}></i>
        </div>
      </div>
      <div className="mt-4">
        <Link href={linkHref} className={`${linkColor} text-sm hover:underline`}>
          {linkText}
        </Link>
      </div>
    </div>
  );
};

export default StatCard;
