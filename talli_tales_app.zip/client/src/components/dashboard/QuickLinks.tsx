import { Link } from "wouter";

interface QuickLinkProps {
  icon: string;
  iconColor: string;
  iconBgColor: string;
  text: string;
  href?: string;
  onClick?: () => void;
}

const QuickLink = ({ icon, iconColor, iconBgColor, text, href, onClick }: QuickLinkProps) => {
  const content = (
    <div className="bg-neutral-50 hover:bg-primary/10 rounded-lg p-4 text-center transition duration-200">
      <div className={`h-10 w-10 ${iconBgColor} rounded-full flex items-center justify-center mx-auto`}>
        <i className={`${icon} ${iconColor}`}></i>
      </div>
      <p className="mt-2 text-sm font-medium">{text}</p>
    </div>
  );
  
  if (href) {
    return <Link href={href}>{content}</Link>;
  }
  
  return <button onClick={onClick} className="block w-full">{content}</button>;
};

interface QuickLinksProps {
  openModal: (modalId: string) => void;
}

const QuickLinks = ({ openModal }: QuickLinksProps) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6 border-b border-neutral-200">
        <h3 className="text-lg font-bold">Quick Links</h3>
      </div>
      
      <div className="p-4">
        <div className="grid grid-cols-2 gap-3">
          <QuickLink 
            icon="fas fa-clock" 
            iconColor="text-primary" 
            iconBgColor="bg-primary/20" 
            text="Add Timesheet" 
            onClick={() => openModal('add-timesheet-modal')}
          />
          
          <QuickLink 
            icon="fas fa-file-alt" 
            iconColor="text-info" 
            iconBgColor="bg-info/20" 
            text="Service Request"
            onClick={() => openModal('service-request-modal')}
          />
          
          <QuickLink 
            icon="fas fa-money-bill-alt" 
            iconColor="text-success" 
            iconBgColor="bg-success/20" 
            text="Submit Claim"
            href="/user/submit-claim/"
          />
          
          <QuickLink 
            icon="fas fa-map-marker-alt" 
            iconColor="text-warning" 
            iconBgColor="bg-warning/20" 
            text="Tag Location"
            onClick={() => openModal('tag-location-modal')}
          />
          
          <QuickLink 
            icon="fas fa-user" 
            iconColor="text-primary" 
            iconBgColor="bg-primary/20" 
            text="My Profile"
            href="/profile"
          />
          
          <QuickLink 
            icon="fas fa-calendar-alt" 
            iconColor="text-danger" 
            iconBgColor="bg-danger/20" 
            text="Holiday Calendar"
            href="/holiday-calendar"
          />
        </div>
      </div>
    </div>
  );
};

export default QuickLinks;
