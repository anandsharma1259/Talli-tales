import { useState } from "react";
import { Link, useLocation } from "wouter";

interface SidebarProps {
  isOpen: boolean;
  isMobile: boolean;
  closeSidebar: () => void;
  openModal: (modalId: string) => void;
}

interface SidebarMenuItemProps {
  icon: string;
  text: string;
  href?: string;
  onClick?: () => void;
  active?: boolean;
  submenu?: {
    text: string;
    href: string;
  }[];
}

const SidebarMenuItem = ({ icon, text, href, onClick, active, submenu }: SidebarMenuItemProps) => {
  const [isSubmenuOpen, setIsSubmenuOpen] = useState(false);
  
  const toggleSubmenu = (e: React.MouseEvent) => {
    if (submenu) {
      e.preventDefault();
      setIsSubmenuOpen(!isSubmenuOpen);
    }
  };
  
  const baseClasses = "flex items-center space-x-3 px-4 py-3 text-neutral-700 hover:bg-primary hover:text-white";
  const activeClasses = active ? "bg-primary text-white" : "";
  
  return (
    <>
      {href ? (
        <Link href={href} className={`${baseClasses} ${activeClasses}`}>
          <i className={`${icon} w-5 text-center`}></i>
          <span>{text}</span>
        </Link>
      ) : (
        <button 
          onClick={onClick || toggleSubmenu} 
          className={`w-full text-left ${baseClasses} ${activeClasses} justify-between`}
        >
          <div className="flex items-center space-x-3">
            <i className={`${icon} w-5 text-center`}></i>
            <span>{text}</span>
          </div>
          {submenu && (
            <i className={`fas fa-chevron-down text-xs ${isSubmenuOpen ? "transform rotate-180" : ""}`}></i>
          )}
        </button>
      )}
      
      {submenu && isSubmenuOpen && (
        <div className="bg-neutral-100">
          {submenu.map((item, index) => (
            <Link 
              key={index}
              href={item.href} 
              className="flex items-center space-x-3 pl-12 pr-4 py-2 text-neutral-700 hover:bg-primary hover:text-white"
            >
              <span>{item.text}</span>
            </Link>
          ))}
        </div>
      )}
    </>
  );
};

const Sidebar = ({ isOpen, isMobile, closeSidebar, openModal }: SidebarProps) => {
  const [location] = useLocation();
  
  return (
    <aside 
      id="sidebar" 
      className={`w-64 bg-white shadow-md h-screen overflow-y-auto fixed left-0 top-16 bottom-0 transition-transform duration-300 z-30 ${
        isOpen ? 'transform-none' : '-translate-x-full'
      } ${isMobile ? 'lg:transform-none' : ''}`}
    >
      <div className="p-4 border-b border-neutral-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
            <i className="fas fa-user"></i>
          </div>
          <div>
            <h4 className="font-medium text-sm">Anand</h4>
            <p className="text-xs text-neutral-500">Individual Contributor</p>
          </div>
        </div>
      </div>
      
      <nav className="mt-4">
        <div className="px-4 mb-2">
          <h5 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">
            Main Navigation
          </h5>
        </div>
        
        <SidebarMenuItem 
          icon="fas fa-home" 
          text="Dashboard" 
          href="/" 
          active={location === "/"} 
        />
        
        <SidebarMenuItem 
          icon="fas fa-user" 
          text="My Profile" 
          href="/profile" 
          active={location === "/profile"} 
        />
        
        <SidebarMenuItem 
          icon="fas fa-tasks" 
          text="My Tasks" 
          active={location.startsWith("/tasks")} 
          submenu={[
            { text: "Assigned Tasks", href: "/tasks/assigned" },
            { text: "Completed Tasks", href: "/tasks/completed" },
            { text: "All Tasks", href: "/tasks/all" }
          ]}
        />
        
        <SidebarMenuItem 
          icon="fas fa-clock" 
          text="Timesheet" 
          active={location.startsWith("/timesheet")} 
          submenu={[
            { text: "Add Timesheet", href: "/timesheet/add" },
            { text: "View Timesheet", href: "/timesheet/view" }
          ]}
        />
        
        <SidebarMenuItem 
          icon="fas fa-calendar-alt" 
          text="Attendance" 
          active={location.startsWith("/attendance")} 
          submenu={[
            { text: "Daily Attendance", href: "/attendance/daily" },
            { text: "Monthly Attendance", href: "/attendance/monthly" },
            { text: "Forgot Geo Tag", href: "/attendance/forget-tag" }
          ]}
        />
        
        <SidebarMenuItem 
          icon="fas fa-file-alt" 
          text="Service Requests" 
          active={location.startsWith("/service-requests")} 
          submenu={[
            { text: "New Request", href: "/service-requests/new" },
            { text: "Request History", href: "/service-requests/history" }
          ]}
        />
        
        <SidebarMenuItem 
          icon="fas fa-money-bill-alt" 
          text="Claims" 
          active={location.startsWith("/claims")} 
          submenu={[
            { text: "Submit Claim", href: "/claims/submit" },
            { text: "Claim History", href: "/claims/history" }
          ]}
        />
        
        <div className="px-4 mt-6 mb-2">
          <h5 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">
            Explore
          </h5>
        </div>
        
        <SidebarMenuItem 
          icon="fas fa-wine-bottle" 
          text="Our Products" 
          href="/dashboard/our-products" 
          active={location === "/dashboard/our-products"} 
        />
        
        <SidebarMenuItem 
          icon="fas fa-building" 
          text="Our Offices" 
          href="/dashboard/our-offices" 
          active={location === "/dashboard/our-offices"} 
        />
        
        <SidebarMenuItem 
          icon="fas fa-comment" 
          text="Feedback" 
          href="/module/add-feedback" 
          active={location === "/module/add-feedback"} 
        />
        
        <div className="px-4 mt-6 mb-2">
          <h5 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">
            Administration
          </h5>
        </div>
        
        <SidebarMenuItem 
          icon="fas fa-shield-alt" 
          text="Admin Dashboard" 
          href="/admin" 
          active={location === "/admin"} 
        />
      </nav>
    </aside>
  );
};

export default Sidebar;
