import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const MakeAdminButton = () => {
  const { toast } = useToast();
  const [isAdmin, setIsAdmin] = useState(false);

  const toggleAdminMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/toggle");
      return await res.json();
    },
    onSuccess: (data) => {
      setIsAdmin(!!data.isAdmin);
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      
      toast({
        title: data.isAdmin ? "Admin access granted!" : "Admin access revoked",
        description: data.isAdmin 
          ? "You now have admin privileges." 
          : "You no longer have admin privileges.",
        variant: data.isAdmin ? "default" : "destructive",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to toggle admin status: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  return (
    <Button 
      onClick={() => toggleAdminMutation.mutate()}
      variant={isAdmin ? "destructive" : "default"}
      className="w-full mt-4"
      disabled={toggleAdminMutation.isPending}
    >
      {toggleAdminMutation.isPending ? "Processing..." : (isAdmin ? "Revoke Admin Access" : "Make Me Admin")}
    </Button>
  );
};

export default MakeAdminButton;