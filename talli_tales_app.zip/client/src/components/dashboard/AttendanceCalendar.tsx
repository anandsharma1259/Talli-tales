import { useState } from "react";

const AttendanceCalendar = () => {
  const [currentMonth, setCurrentMonth] = useState("April 2025");
  
  // This is for demonstration - in a real app, this would come from an API
  const calendarDays = [
    // Week 1
    { day: 30, month: "prev", status: "" },
    { day: 31, month: "prev", status: "" },
    { day: 1, month: "current", status: "" },
    { day: 2, month: "current", status: "" },
    { day: 3, month: "current", status: "" },
    { day: 4, month: "current", status: "" },
    { day: 5, month: "current", status: "" },
    
    // Week 2
    { day: 6, month: "current", status: "" },
    { day: 7, month: "current", status: "" },
    { day: 8, month: "current", status: "" },
    { day: 9, month: "current", status: "" },
    { day: 10, month: "current", status: "" },
    { day: 11, month: "current", status: "" },
    { day: 12, month: "current", status: "" },
    
    // Week 3
    { day: 13, month: "current", status: "" },
    { day: 14, month: "current", status: "" },
    { day: 15, month: "current", status: "" },
    { day: 16, month: "current", status: "present" },
    { day: 17, month: "current", status: "present" },
    { day: 18, month: "current", status: "present" },
    { day: 19, month: "current", status: "" },
    
    // Week 4
    { day: 20, month: "current", status: "" },
    { day: 21, month: "current", status: "today" },
    { day: 22, month: "current", status: "" },
    { day: 23, month: "current", status: "" },
    { day: 24, month: "current", status: "" },
    { day: 25, month: "current", status: "" },
    { day: 26, month: "current", status: "" },
    
    // Week 5
    { day: 27, month: "current", status: "" },
    { day: 28, month: "current", status: "" },
    { day: 29, month: "current", status: "" },
    { day: 30, month: "current", status: "" },
    { day: 1, month: "next", status: "" },
    { day: 2, month: "next", status: "" },
    { day: 3, month: "next", status: "" },
  ];

  const getClassesForDay = (day: any) => {
    let classes = "text-center p-2";
    
    if (day.month !== "current") {
      classes += " text-neutral-400";
    }
    
    if (day.status === "today") {
      classes += " bg-primary/20 text-primary rounded-md font-bold";
    } else if (day.status === "present") {
      classes += " bg-success/20 text-success rounded-md";
    } else if (day.status === "absent") {
      classes += " bg-danger/20 text-danger rounded-md";
    } else if (day.status === "leave") {
      classes += " bg-warning/20 text-warning rounded-md";
    }
    
    return classes;
  };

  const navigatePreviousMonth = () => {
    // In a real app, this would update the calendar data
    setCurrentMonth("March 2025");
  };

  const navigateNextMonth = () => {
    // In a real app, this would update the calendar data
    setCurrentMonth("May 2025");
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="p-6 border-b border-neutral-200">
        <h3 className="text-lg font-bold">Monthly Attendance</h3>
      </div>
      
      <div className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h4 className="text-base font-medium">{currentMonth}</h4>
          <div className="flex space-x-2">
            <button 
              className="text-neutral-500 hover:text-primary"
              onClick={navigatePreviousMonth}
            >
              <i className="fas fa-chevron-left"></i>
            </button>
            <button 
              className="text-neutral-500 hover:text-primary"
              onClick={navigateNextMonth}
            >
              <i className="fas fa-chevron-right"></i>
            </button>
          </div>
        </div>
        
        <div className="mb-4">
          <div className="grid grid-cols-7 gap-1">
            <div className="text-center text-xs text-neutral-500 font-medium">SUN</div>
            <div className="text-center text-xs text-neutral-500 font-medium">MON</div>
            <div className="text-center text-xs text-neutral-500 font-medium">TUE</div>
            <div className="text-center text-xs text-neutral-500 font-medium">WED</div>
            <div className="text-center text-xs text-neutral-500 font-medium">THU</div>
            <div className="text-center text-xs text-neutral-500 font-medium">FRI</div>
            <div className="text-center text-xs text-neutral-500 font-medium">SAT</div>
          </div>
          
          <div className="grid grid-cols-7 gap-1 mt-2">
            {calendarDays.map((day, index) => (
              <div key={index} className={getClassesForDay(day)}>
                {day.day}
              </div>
            ))}
          </div>
        </div>
        
        <div className="flex justify-between items-center text-sm">
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-success/20 mr-2"></div>
            <span>Present</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-danger/20 mr-2"></div>
            <span>Absent</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-warning/20 mr-2"></div>
            <span>Leave</span>
          </div>
        </div>
        
        <div className="mt-6">
          <Link href="/attendance/monthly" className="text-primary hover:underline text-sm">
            View full attendance record
          </Link>
        </div>
      </div>
    </div>
  );
};

// Add this import at the top of the file
import { Link } from "wouter";

export default AttendanceCalendar;
