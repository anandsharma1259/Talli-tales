import { useState, useEffect } from "react";

const DashboardWelcome = () => {
  const [greeting, setGreeting] = useState("");
  const [currentDate, setCurrentDate] = useState("");
  const [checkInTime, setCheckInTime] = useState("09:00 AM");
  
  useEffect(() => {
    updateDateTime();
  }, []);
  
  const updateDateTime = () => {
    const now = new Date();
    
    // Set greeting based on time of day
    const hour = now.getHours();
    let greetingText = 'Good morning';
    
    if (hour >= 12 && hour < 17) {
      greetingText = 'Good afternoon';
    } else if (hour >= 17) {
      greetingText = 'Good evening';
    }
    
    setGreeting(greetingText);
    
    // Format date
    const options: Intl.DateTimeFormatOptions = { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    };
    setCurrentDate(now.toLocaleDateString('en-US', options));
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-neutral-800">
            Welcome to Talli Tales, <span>Anand Sharma</span>!
          </h1>
          <p className="text-neutral-600 mt-1">
            <span>{greeting}</span> • <span>{currentDate}</span>
          </p>
        </div>
        <div className="mt-4 md:mt-0">
          <div className="bg-primary/10 rounded-lg px-4 py-3">
            <div className="flex items-center">
              <div className="mr-3">
                <i className="fas fa-calendar-check text-2xl text-primary"></i>
              </div>
              <div>
                <p className="text-sm font-medium">Today's Attendance</p>
                <p className="text-sm">Check-in: {checkInTime}</p>
              </div>
              <button className="ml-4 bg-primary hover:bg-primary/90 text-white py-2 px-4 rounded-md text-sm">
                Check Out
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardWelcome;
