import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Sample office data
const offices = [
  {
    id: 1,
    name: "Corporate Headquarters",
    address: "Talli Tales Tower, Cyber City, Gurugram 122002, India",
    phone: "+91 124 456 7890",
    email: "info@tallitales.com",
    hours: "Monday - Friday: 9:00 AM - 6:00 PM",
    image: "fas fa-building"
  },
  {
    id: 2,
    name: "Mumbai Office",
    address: "Talli Tales House, Bandra Kurla Complex, Mumbai 400051, India",
    phone: "+91 22 2345 6789",
    email: "mumbai@tallitales.com",
    hours: "Monday - Friday: 9:00 AM - 6:00 PM",
    image: "fas fa-city"
  },
  {
    id: 3,
    name: "Bangalore Operations Center",
    address: "Talli Tales Plaza, Whitefield, Bangalore 560066, India",
    phone: "+91 80 4567 8901",
    email: "bangalore@tallitales.com",
    hours: "Monday - Friday: 9:00 AM - 6:00 PM",
    image: "fas fa-building"
  },
  {
    id: 4,
    name: "Chennai Distribution Center",
    address: "Talli Tales Warehouse, Ambattur Industrial Estate, Chennai 600058, India",
    phone: "+91 44 2345 6789",
    email: "chennai@tallitales.com",
    hours: "Monday - Saturday: 8:00 AM - 7:00 PM",
    image: "fas fa-warehouse"
  },
  {
    id: 5,
    name: "Kolkata Regional Office",
    address: "Talli Tales Center, Salt Lake City, Kolkata 700091, India",
    phone: "+91 33 6789 0123",
    email: "kolkata@tallitales.com",
    hours: "Monday - Friday: 9:00 AM - 6:00 PM",
    image: "fas fa-building"
  },
  {
    id: 6,
    name: "Delhi NCR Sales Office",
    address: "Talli Tales Point, Connaught Place, New Delhi 110001, India",
    phone: "+91 11 2345 6789",
    email: "delhi@tallitales.com",
    hours: "Monday - Friday: 9:00 AM - 6:00 PM",
    image: "fas fa-store"
  }
];

const OurOffices = () => {
  return (
    <div className="container mx-auto">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-primary">Our Offices</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-neutral-600">
            Talli Tales has a strong presence across India with corporate offices, distribution centers, and sales offices in major cities. Our nationwide network ensures efficient service delivery and customer support.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        {offices.map((office) => (
          <Card key={office.id} className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start mb-4">
                <div className="h-12 w-12 bg-primary/10 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                  <i className={`${office.image} text-primary`}></i>
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1">{office.name}</h3>
                  <p className="text-neutral-600 text-sm">{office.address}</p>
                </div>
              </div>
              
              <div className="space-y-2 text-sm text-neutral-600">
                <div className="flex items-center">
                  <i className="fas fa-phone-alt w-5 text-primary"></i>
                  <span>{office.phone}</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-envelope w-5 text-primary"></i>
                  <span>{office.email}</span>
                </div>
                <div className="flex items-center">
                  <i className="fas fa-clock w-5 text-primary"></i>
                  <span>{office.hours}</span>
                </div>
              </div>
              
              <div className="mt-4 flex justify-between">
                <button className="text-primary hover:underline text-sm flex items-center">
                  <i className="fas fa-directions mr-1"></i>
                  <span>Get Directions</span>
                </button>
                <button className="text-primary hover:underline text-sm flex items-center">
                  <i className="fas fa-info-circle mr-1"></i>
                  <span>More Info</span>
                </button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-xl font-bold">Global Presence</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-neutral-600">
            Besides our strong presence in India, Talli Tales has expanded globally with distribution partners in over 20 countries. Our international exports division caters to markets in Asia, Europe, and North America.
          </p>
          
          <div className="mt-4">
            <button className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 flex items-center">
              <i className="fas fa-globe-asia mr-2"></i>
              View Global Network
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default OurOffices;
