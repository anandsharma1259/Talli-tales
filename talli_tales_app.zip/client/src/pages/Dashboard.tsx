import DashboardWelcome from "@/components/dashboard/DashboardWelcome";
import StatCard from "@/components/dashboard/StatCard";
import TaskList from "@/components/dashboard/TaskList";
import Announcements from "@/components/dashboard/Announcements";
import AttendanceCalendar from "@/components/dashboard/AttendanceCalendar";
import QuickLinks from "@/components/dashboard/QuickLinks";
import UpcomingHolidays from "@/components/dashboard/UpcomingHolidays";
import MakeAdminButton from "@/components/dashboard/MakeAdminButton";
import DownloadAppButton from "@/components/dashboard/DownloadAppButton";

interface DashboardProps {
  openModal?: (modalId: string) => void;
}

const Dashboard = ({ openModal = () => {} }: DashboardProps) => {
  return (
    <>
      <DashboardWelcome />
      
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <StatCard 
          title="Tasks Pending"
          value="7"
          change="+2"
          status="since yesterday"
          icon="fas fa-tasks"
          iconBgColor="bg-primary/10"
          iconColor="text-primary"
          linkText="View all tasks"
          linkHref="/tasks"
          linkColor="text-danger"
        />
        
        <StatCard 
          title="Timesheet Status"
          value="94%"
          status="Complete for this week"
          icon="fas fa-clock"
          iconBgColor="bg-success/10"
          iconColor="text-success"
          linkText="Fill missing hours"
          linkHref="/timesheet"
          linkColor="text-success"
        />
        
        <StatCard 
          title="Service Requests"
          value="2"
          status="1 pending approval"
          icon="fas fa-file-alt"
          iconBgColor="bg-warning/10"
          iconColor="text-warning"
          linkText="View requests"
          linkHref="/service-requests"
          linkColor="text-warning"
        />
        
        <StatCard 
          title="Claims"
          value="₹4.2K"
          status="2 claims in process"
          icon="fas fa-money-bill-alt"
          iconBgColor="bg-info/10"
          iconColor="text-info"
          linkText="Submit new claim"
          linkHref="/claims"
          linkColor="text-info"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Task List and Announcements Section */}
        <div className="lg:col-span-2">
          <TaskList />
          <Announcements />
        </div>
        
        {/* Right Sidebar Content */}
        <div className="space-y-6">
          <AttendanceCalendar />
          <QuickLinks openModal={openModal} />
          <UpcomingHolidays />
          
          {/* Admin Control Panel */}
          <div className="bg-white shadow-md rounded-lg p-4">
            <h3 className="text-lg font-medium mb-3">Admin Control</h3>
            <p className="text-sm text-gray-600 mb-3">
              Toggle your admin status to access additional features.
            </p>
            <MakeAdminButton />
            
            <div className="mt-4 pt-4 border-t border-gray-200">
              <h4 className="text-md font-medium mb-2">Application Management</h4>
              <p className="text-sm text-gray-600 mb-3">
                Download the application code for offline use or deployment.
              </p>
              <DownloadAppButton />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
