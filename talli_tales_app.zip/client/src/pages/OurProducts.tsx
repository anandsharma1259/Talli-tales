import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

// Sample product data
const products = [
  {
    id: 1,
    name: "Premium Whisky Collection",
    description: "Our flagship collection of premium whiskies, aged to perfection with rich, complex flavors.",
    image: "fas fa-glass-whiskey",
    category: "Whisky",
  },
  {
    id: 2,
    name: "Signature Vodka Series",
    description: "Ultra-smooth, triple-distilled vodka made from the finest ingredients for a clean, crisp taste.",
    image: "fas fa-wine-bottle",
    category: "Vodka",
  },
  {
    id: 3,
    name: "Craft Gin Selection",
    description: "Artisanal gins infused with botanical flavors, perfect for sophisticated cocktails.",
    image: "fas fa-cocktail",
    category: "Gin",
  },
  {
    id: 4,
    name: "Luxury Rum Reserve",
    description: "Aged Caribbean rums with notes of caramel, vanilla, and tropical fruits for a smooth finish.",
    image: "fas fa-glass-cheers",
    category: "Rum",
  },
  {
    id: 5,
    name: "Talli Tales Tequila",
    description: "Premium tequila made from 100% blue agave, offering a perfect balance of flavor and smoothness.",
    image: "fas fa-lemon",
    category: "Tequila",
  },
  {
    id: 6,
    name: "Exotic Liqueurs",
    description: "A collection of unique liqueurs featuring exotic flavors from around the world.",
    image: "fas fa-glass-martini-alt",
    category: "Liqueurs",
  },
];

const OurProducts = () => {
  return (
    <div className="container mx-auto">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-primary">Our Products</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-neutral-600">
            Talli Tales offers a premium range of spirits and beverages crafted to perfection. Our product portfolio includes award-winning whiskies, vodkas, gins, and more, catering to diverse tastes and occasions.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        {products.map((product) => (
          <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="h-36 bg-primary/10 flex items-center justify-center">
              <i className={`${product.image} text-primary text-5xl`}></i>
            </div>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-lg font-bold">{product.name}</h3>
                <span className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
                  {product.category}
                </span>
              </div>
              <p className="text-neutral-600 text-sm">{product.description}</p>
              <button className="mt-4 text-primary hover:underline text-sm flex items-center">
                <span>View Details</span>
                <i className="fas fa-arrow-right ml-1 text-xs"></i>
              </button>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-xl font-bold">Product Catalog</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-neutral-600 mb-4">
            Download our complete product catalog with detailed information about each product, pricing, and availability.
          </p>
          <button className="px-4 py-2 bg-primary text-white rounded-md hover:bg-primary/90 flex items-center">
            <i className="fas fa-download mr-2"></i>
            Download Catalog
          </button>
        </CardContent>
      </Card>
    </div>
  );
};

export default OurProducts;
