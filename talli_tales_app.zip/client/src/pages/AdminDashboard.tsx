import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("users");
  
  const { data: userData, isLoading: isLoadingUser } = useQuery({
    queryKey: ['/api/user/profile'],
    queryFn: getQueryFn({ on401: "throw" }),
  });
  
  if (isLoadingUser) {
    return (
      <div className="flex items-center justify-center min-h-[300px]">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }
  
  if (!userData?.isAdmin) {
    return (
      <div className="bg-white rounded-lg p-6 shadow-md my-6">
        <h2 className="text-2xl font-bold text-danger mb-4">Access Denied</h2>
        <p className="text-neutral-700">
          You do not have permission to access the admin dashboard.
        </p>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h1 className="text-2xl font-bold text-primary mb-4">Admin Dashboard</h1>
        <p className="text-neutral-700 mb-4">
          Welcome to the admin dashboard. From here, you can manage users, content, and system settings.
        </p>
        
        {/* Tabs */}
        <div className="border-b border-neutral-200 mb-6">
          <div className="flex space-x-4">
            <button
              className={`px-4 py-2 font-medium ${
                activeTab === "users"
                  ? "text-primary border-b-2 border-primary"
                  : "text-neutral-500 hover:text-primary"
              }`}
              onClick={() => setActiveTab("users")}
            >
              User Management
            </button>
            <button
              className={`px-4 py-2 font-medium ${
                activeTab === "content"
                  ? "text-primary border-b-2 border-primary"
                  : "text-neutral-500 hover:text-primary"
              }`}
              onClick={() => setActiveTab("content")}
            >
              Content Management
            </button>
            <button
              className={`px-4 py-2 font-medium ${
                activeTab === "settings"
                  ? "text-primary border-b-2 border-primary"
                  : "text-neutral-500 hover:text-primary"
              }`}
              onClick={() => setActiveTab("settings")}
            >
              System Settings
            </button>
            <button
              className={`px-4 py-2 font-medium ${
                activeTab === "logs"
                  ? "text-primary border-b-2 border-primary"
                  : "text-neutral-500 hover:text-primary"
              }`}
              onClick={() => setActiveTab("logs")}
            >
              Logs & Activity
            </button>
          </div>
        </div>
        
        {/* Tab content */}
        {activeTab === "users" && (
          <div>
            <h2 className="text-xl font-semibold mb-4">User Management</h2>
            <p className="mb-4">Manage user accounts, permissions, and roles.</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-primary/10 p-4 rounded-lg shadow-sm">
                <div className="text-3xl font-bold text-primary mb-2">1</div>
                <div className="font-medium text-neutral-700">Total Users</div>
              </div>
              <div className="bg-success/10 p-4 rounded-lg shadow-sm">
                <div className="text-3xl font-bold text-success mb-2">1</div>
                <div className="font-medium text-neutral-700">Admin Users</div>
              </div>
              <div className="bg-warning/10 p-4 rounded-lg shadow-sm">
                <div className="text-3xl font-bold text-warning mb-2">0</div>
                <div className="font-medium text-neutral-700">Locked Accounts</div>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white border border-neutral-200">
                <thead>
                  <tr className="bg-neutral-100">
                    <th className="py-3 px-4 text-left font-medium text-neutral-600">Username</th>
                    <th className="py-3 px-4 text-left font-medium text-neutral-600">Full Name</th>
                    <th className="py-3 px-4 text-left font-medium text-neutral-600">Email</th>
                    <th className="py-3 px-4 text-left font-medium text-neutral-600">Role</th>
                    <th className="py-3 px-4 text-left font-medium text-neutral-600">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-t border-neutral-200">
                    <td className="py-3 px-4">{userData.username}</td>
                    <td className="py-3 px-4">{userData.fullName}</td>
                    <td className="py-3 px-4">{userData.email}</td>
                    <td className="py-3 px-4">
                      <span className="bg-success/20 text-success text-xs px-2 py-1 rounded-full">
                        Admin
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <button className="text-primary hover:underline mr-3">Edit</button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <div className="flex justify-end mt-4">
              <button className="bg-primary text-white px-4 py-2 rounded hover:bg-primary/90">
                Add New User
              </button>
            </div>
          </div>
        )}
        
        {activeTab === "content" && (
          <div>
            <h2 className="text-xl font-semibold mb-4">Content Management</h2>
            <p className="mb-4">Manage website content, announcements, and resources.</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border border-neutral-200 rounded-lg p-4">
                <h3 className="font-medium text-lg mb-2">Announcements</h3>
                <p className="text-neutral-600 text-sm mb-3">
                  Manage company-wide announcements that appear on the dashboard.
                </p>
                <button className="text-primary text-sm hover:underline">
                  Manage Announcements
                </button>
              </div>
              
              <div className="border border-neutral-200 rounded-lg p-4">
                <h3 className="font-medium text-lg mb-2">Resources</h3>
                <p className="text-neutral-600 text-sm mb-3">
                  Manage downloadable resources and documents for employees.
                </p>
                <button className="text-primary text-sm hover:underline">
                  Manage Resources
                </button>
              </div>
              
              <div className="border border-neutral-200 rounded-lg p-4">
                <h3 className="font-medium text-lg mb-2">Quick Links</h3>
                <p className="text-neutral-600 text-sm mb-3">
                  Manage quick links shown on the dashboard.
                </p>
                <button className="text-primary text-sm hover:underline">
                  Manage Quick Links
                </button>
              </div>
              
              <div className="border border-neutral-200 rounded-lg p-4">
                <h3 className="font-medium text-lg mb-2">Holiday Calendar</h3>
                <p className="text-neutral-600 text-sm mb-3">
                  Manage the upcoming holidays shown on the dashboard.
                </p>
                <button className="text-primary text-sm hover:underline">
                  Manage Holiday Calendar
                </button>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === "settings" && (
          <div>
            <h2 className="text-xl font-semibold mb-4">System Settings</h2>
            <p className="mb-4">Configure system-wide settings and preferences.</p>
            
            <div className="space-y-6">
              <div className="border border-neutral-200 rounded-lg p-4">
                <h3 className="font-medium text-lg mb-3">Application Settings</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Application Name</h4>
                      <p className="text-sm text-neutral-600">The name of the application</p>
                    </div>
                    <input 
                      type="text" 
                      value="Talli Tales" 
                      className="border border-neutral-300 rounded px-3 py-2 w-64"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Primary Color</h4>
                      <p className="text-sm text-neutral-600">Main color theme for the application</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-primary rounded border border-neutral-300"></div>
                      <input 
                        type="text" 
                        value="#8842C8" 
                        className="border border-neutral-300 rounded px-3 py-2 w-32"
                      />
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Maintenance Mode</h4>
                      <p className="text-sm text-neutral-600">Put the application in maintenance mode</p>
                    </div>
                    <label className="inline-flex items-center cursor-pointer">
                      <input type="checkbox" value="" className="sr-only peer" />
                      <div className="relative w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/30 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                  </div>
                </div>
                
                <div className="mt-4 border-t border-neutral-200 pt-4 flex justify-end">
                  <button className="bg-primary text-white px-4 py-2 rounded hover:bg-primary/90">
                    Save Settings
                  </button>
                </div>
              </div>
              
              <div className="border border-neutral-200 rounded-lg p-4">
                <h3 className="font-medium text-lg mb-3">Security Settings</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Two-Factor Authentication</h4>
                      <p className="text-sm text-neutral-600">Require 2FA for all admin accounts</p>
                    </div>
                    <label className="inline-flex items-center cursor-pointer">
                      <input type="checkbox" value="" className="sr-only peer" />
                      <div className="relative w-11 h-6 bg-neutral-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/30 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-neutral-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Session Timeout</h4>
                      <p className="text-sm text-neutral-600">Timeout period in minutes</p>
                    </div>
                    <input 
                      type="number" 
                      value="30" 
                      className="border border-neutral-300 rounded px-3 py-2 w-32"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Password Policy</h4>
                      <p className="text-sm text-neutral-600">Minimum password length</p>
                    </div>
                    <input 
                      type="number" 
                      value="8" 
                      className="border border-neutral-300 rounded px-3 py-2 w-32"
                    />
                  </div>
                </div>
                
                <div className="mt-4 border-t border-neutral-200 pt-4 flex justify-end">
                  <button className="bg-primary text-white px-4 py-2 rounded hover:bg-primary/90">
                    Save Settings
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === "logs" && (
          <div>
            <h2 className="text-xl font-semibold mb-4">Logs & Activity</h2>
            <p className="mb-4">View system logs and user activity.</p>
            
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <select className="border border-neutral-300 rounded px-3 py-2">
                  <option>All Logs</option>
                  <option>Error Logs</option>
                  <option>Authentication Logs</option>
                  <option>System Logs</option>
                </select>
                <input 
                  type="date" 
                  className="border border-neutral-300 rounded px-3 py-2"
                />
              </div>
              <button className="text-primary hover:underline">
                Export Logs
              </button>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full bg-white border border-neutral-200">
                <thead>
                  <tr className="bg-neutral-100">
                    <th className="py-3 px-4 text-left font-medium text-neutral-600">Timestamp</th>
                    <th className="py-3 px-4 text-left font-medium text-neutral-600">Level</th>
                    <th className="py-3 px-4 text-left font-medium text-neutral-600">User</th>
                    <th className="py-3 px-4 text-left font-medium text-neutral-600">Message</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-t border-neutral-200">
                    <td className="py-3 px-4 text-sm">{new Date().toLocaleString()}</td>
                    <td className="py-3 px-4">
                      <span className="bg-success/20 text-success text-xs px-2 py-1 rounded-full">
                        INFO
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm">{userData.username}</td>
                    <td className="py-3 px-4 text-sm">User logged in successfully</td>
                  </tr>
                  <tr className="border-t border-neutral-200">
                    <td className="py-3 px-4 text-sm">{new Date().toLocaleString()}</td>
                    <td className="py-3 px-4">
                      <span className="bg-info/20 text-info text-xs px-2 py-1 rounded-full">
                        SYSTEM
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm">system</td>
                    <td className="py-3 px-4 text-sm">Application started</td>
                  </tr>
                </tbody>
              </table>
            </div>
            
            <div className="flex justify-between items-center mt-4">
              <div className="text-sm text-neutral-600">
                Showing 2 of 2 logs
              </div>
              <div className="flex space-x-2">
                <button className="px-3 py-1 border border-neutral-300 rounded bg-neutral-100 text-neutral-600 disabled:opacity-50" disabled>
                  Previous
                </button>
                <button className="px-3 py-1 border border-neutral-300 rounded bg-neutral-100 text-neutral-600 disabled:opacity-50" disabled>
                  Next
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;