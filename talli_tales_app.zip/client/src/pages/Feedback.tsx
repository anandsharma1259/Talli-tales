import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

const Feedback = () => {
  const { toast } = useToast();
  const [feedbackType, setFeedbackType] = useState("suggestion");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Here we would normally submit to the backend
    console.log({
      feedbackType,
      subject,
      message,
      isAnonymous
    });
    
    // Show success toast
    toast({
      title: "Feedback Submitted",
      description: "Thank you for your feedback. We appreciate your input!",
      variant: "default",
    });
    
    // Reset form
    setFeedbackType("suggestion");
    setSubject("");
    setMessage("");
    setIsAnonymous(false);
  };
  
  return (
    <div className="container mx-auto max-w-3xl">
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-primary">Share Your Feedback</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-neutral-600 mb-6">
            Your feedback is important to us and helps us improve our services. Please share your thoughts, suggestions, or concerns with us.
          </p>
          
          <form onSubmit={handleSubmit}>
            <div className="mb-6">
              <label className="block text-sm font-medium text-neutral-700 mb-2">
                Feedback Type
              </label>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div 
                  className={`border rounded-md p-4 cursor-pointer transition-colors ${
                    feedbackType === "suggestion" ? "border-primary bg-primary/5" : "border-neutral-200 hover:border-primary"
                  }`}
                  onClick={() => setFeedbackType("suggestion")}
                >
                  <div className="flex items-center">
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center mr-3 ${
                      feedbackType === "suggestion" ? "border-primary" : "border-neutral-300"
                    }`}>
                      {feedbackType === "suggestion" && <div className="w-3 h-3 rounded-full bg-primary"></div>}
                    </div>
                    <span className="font-medium">Suggestion</span>
                  </div>
                </div>
                
                <div 
                  className={`border rounded-md p-4 cursor-pointer transition-colors ${
                    feedbackType === "complaint" ? "border-primary bg-primary/5" : "border-neutral-200 hover:border-primary"
                  }`}
                  onClick={() => setFeedbackType("complaint")}
                >
                  <div className="flex items-center">
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center mr-3 ${
                      feedbackType === "complaint" ? "border-primary" : "border-neutral-300"
                    }`}>
                      {feedbackType === "complaint" && <div className="w-3 h-3 rounded-full bg-primary"></div>}
                    </div>
                    <span className="font-medium">Complaint</span>
                  </div>
                </div>
                
                <div 
                  className={`border rounded-md p-4 cursor-pointer transition-colors ${
                    feedbackType === "appreciation" ? "border-primary bg-primary/5" : "border-neutral-200 hover:border-primary"
                  }`}
                  onClick={() => setFeedbackType("appreciation")}
                >
                  <div className="flex items-center">
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center mr-3 ${
                      feedbackType === "appreciation" ? "border-primary" : "border-neutral-300"
                    }`}>
                      {feedbackType === "appreciation" && <div className="w-3 h-3 rounded-full bg-primary"></div>}
                    </div>
                    <span className="font-medium">Appreciation</span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <label htmlFor="feedback-subject" className="block text-sm font-medium text-neutral-700 mb-2">
                Subject
              </label>
              <Input 
                id="feedback-subject" 
                placeholder="Enter subject" 
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                required
              />
            </div>
            
            <div className="mb-6">
              <label htmlFor="feedback-message" className="block text-sm font-medium text-neutral-700 mb-2">
                Your Feedback
              </label>
              <Textarea 
                id="feedback-message" 
                placeholder="Please provide detailed feedback..." 
                rows={6}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                required
              />
            </div>
            
            <div className="mb-6">
              <div className="flex items-center">
                <input 
                  type="checkbox" 
                  id="anonymous-feedback" 
                  className="w-4 h-4 text-primary border-neutral-300 rounded focus:ring-primary"
                  checked={isAnonymous}
                  onChange={(e) => setIsAnonymous(e.target.checked)}
                />
                <label htmlFor="anonymous-feedback" className="ml-2 block text-sm text-neutral-700">
                  Submit anonymously (your name will not be associated with this feedback)
                </label>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3">
              <Button type="button" variant="outline">
                Cancel
              </Button>
              <Button type="submit">
                Submit Feedback
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold">Previous Feedback</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-neutral-600">
            You can view your previously submitted feedback and their status here.
          </p>
          
          <div className="mt-4 text-center p-6 bg-neutral-50 rounded-md">
            <i className="fas fa-comments text-neutral-300 text-4xl mb-3"></i>
            <p className="text-neutral-500">You haven't submitted any feedback yet.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Feedback;
