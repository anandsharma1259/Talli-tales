import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import OurProducts from "@/pages/OurProducts";
import OurOffices from "@/pages/OurOffices";
import Feedback from "@/pages/Feedback";
import AdminDashboard from "@/pages/AdminDashboard";
import DashboardLayout from "./layouts/DashboardLayout";
import { useState, useCallback } from "react";

// Create a wrapper to handle route components
const RouteWrapper = () => {
  const [location] = useLocation();
  
  const handleOpenModal = useCallback((modalId: string) => {
    // Modal opening logic here
    console.log("Opening modal:", modalId);
  }, []);
  
  // Return the appropriate component based on the current route
  switch (location) {
    case "/":
      return <Dashboard openModal={handleOpenModal} />;
    case "/dashboard/our-products":
      return <OurProducts />;
    case "/dashboard/our-offices":
      return <OurOffices />;
    case "/module/add-feedback":
      return <Feedback />;
    case "/admin":
      return <AdminDashboard />;
    default:
      return <NotFound />;
  }
};

function Router() {
  return (
    <Switch>
      <Route path="/" component={() => <RouteWrapper />} />
      <Route path="/dashboard/our-products" component={() => <RouteWrapper />} />
      <Route path="/dashboard/our-offices" component={() => <RouteWrapper />} />
      <Route path="/module/add-feedback" component={() => <RouteWrapper />} />
      <Route path="/admin" component={() => <RouteWrapper />} />
      <Route component={() => <RouteWrapper />} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <DashboardLayout>
          <Router />
        </DashboardLayout>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
