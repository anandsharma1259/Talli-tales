import { useState, useEffect, ReactNode } from "react";
import Navbar from "@/components/dashboard/Navbar";
import Sidebar from "@/components/dashboard/Sidebar";
import AddTaskModal from "@/components/modals/AddTaskModal";
import AddTimesheetModal from "@/components/modals/AddTimesheetModal";
import ServiceRequestModal from "@/components/modals/ServiceRequestModal";
import TagLocationModal from "@/components/modals/TagLocationModal";

interface DashboardLayoutProps {
  children: ReactNode;
}

const DashboardLayout = ({ children }: DashboardLayoutProps) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  
  const [activeModal, setActiveModal] = useState<string | null>(null);
  
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => {
      window.removeEventListener('resize', checkMobile);
    };
  }, []);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const openModal = (modalId: string) => {
    setActiveModal(modalId);
    document.body.classList.add('overflow-hidden');
  };

  const closeModal = () => {
    setActiveModal(null);
    document.body.classList.remove('overflow-hidden');
  };

  return (
    <div className="min-h-screen bg-neutral-100 font-sans">
      <Navbar 
        toggleSidebar={toggleSidebar} 
        openModal={openModal}
      />
      
      <div className="flex flex-1">
        <Sidebar 
          isOpen={sidebarOpen || !isMobile} 
          isMobile={isMobile}
          closeSidebar={() => setSidebarOpen(false)}
          openModal={openModal}
        />
        
        <main className={`flex-1 p-4 md:p-6 ${!isMobile ? 'lg:ml-64' : ''}`}>
          {children}
        </main>
      </div>
      
      {/* Modals */}
      <AddTaskModal 
        isOpen={activeModal === 'add-task-modal'} 
        onClose={closeModal} 
      />
      
      <AddTimesheetModal 
        isOpen={activeModal === 'add-timesheet-modal'} 
        onClose={closeModal} 
      />
      
      <ServiceRequestModal 
        isOpen={activeModal === 'service-request-modal'} 
        onClose={closeModal} 
      />
      
      <TagLocationModal 
        isOpen={activeModal === 'tag-location-modal'} 
        onClose={closeModal} 
      />
    </div>
  );
};

export default DashboardLayout;
